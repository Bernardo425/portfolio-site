import java.util.Scanner;
public class exercicio7 {
   public static void main(String[] bernardo){
        float temperatura;
        Scanner teclado = new Scanner (System.in);
        System.out.println ("Qual é a temperatura do dia de hoje?");
        temperatura = teclado.nextFloat();

        if (temperatura<10){
            System.out.println("A temperatura está muito fria");

        }else{

        }if ((temperatura>=10) && (temperatura<17)){

        System.out.println ("A tempertaura está ");
    }
    }

}
