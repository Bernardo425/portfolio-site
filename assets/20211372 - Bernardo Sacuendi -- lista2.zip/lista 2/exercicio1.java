import java.util.Scanner;

public class exercicio1 {

    public static void main(String[] bernardo) {

        Scanner in = new Scanner(System.in);

        int x = in.nextInt();
        int y = in.nextInt();
        int z = in.nextInt();

        if(x > y && y > z);
        if(x < 0 && y < 0 );
        if(x >= 0 && y >= 0 );
        if(x == y && x != z);
    }
    
}
