import java.util.Scanner;

public class exercicio9 {

    public static void main(String[] bernardo) {
        Scanner in = new Scanner(System.in);
        System.out.println("Escolha um número de 1 a 5");
        int day = in.nextInt();
        
        if(day == 1)
            System.out.println("Saturday");
        else if(day == 2)
            System.out.println("Sunday");
        else if(day == 3)
            System.out.println("Monday");
        else if(day == 4)
            System.out.println("Tuesday");
        else if(day == 5)
            System.out.println("Wednesday");
        else
            System.out.println("Invalid day");


    }
    
}
