import java.util.Scanner;

public class exercicio10 {
    public static void main(String[] bernardo) {

        Scanner in = new Scanner(System.in);
        
        System.out.println("Insira o dia mês e o ano");
        int dia = in.nextInt();
        int mes = in.nextInt();
        int ano = in.nextInt();
        
        if(mes == 2){
            if(dia >0 && dia <= 29 &&  ano >= 1000 && ano <= 1999 && ano % 400 == 0 || ano % 4 == 0 && ano % 100 != 0)
                System.out.println("É bissexto");
            else
                System.out.println("Não é bissexto");
        }
        else if(mes == 1 ||mes == 3 || mes == 5 || mes == 7 || mes == 8|| mes == 10|| mes == 12 && ano >= 1000 && ano <= 1999 && ano % 400 == 0 || ano % 4 == 0 && ano % 100 != 0 ){
            if(dia < 32 && dia > 0 && ano % 400 == 0 || ano % 4 == 0 && ano % 100 != 0)
                System.out.println("É bissexto");
            else
                System.out.println("Não é bissexto");
        }
        else if(mes == 6 ||mes == 4 || mes == 9 || mes == 11 && ano >= 1000 && ano <= 1999 && ano % 400 == 0 || ano % 4 == 0 && ano % 100 != 0 ){
            if(dia < 32 && dia > 0 && ano % 400 == 0 || ano % 4 == 0 && ano % 100 != 0)
                System.out.println("É bissexto");
            else
                System.out.println("Não é bissexto");
      }
        else
            System.out.println("Um dos digítos é inválido");
        // TODO code application logic here
    }
    
}
