import java.util.Scanner;

public class exercicio3 {

    public static void main(String[] bernardo) {
        
        Scanner in = new Scanner(System.in);
        float nota = in.nextFloat();
        
        String resultado = (nota>=10)?"Reprovado":"Aprovado";        
        System.out.println(resultado);
        
        
        
    }
    
}
