import java.util.Scanner;

public class exercicio5 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        float avaliacao1, avaliacao2, avaliacao3;
        float alta, baixa;


        System.out.printf("Digite a avaliação 1\n");
        avaliacao1 = in.nextFloat();

        System.out.printf("Digite a avaliação 2\n");
        avaliacao2 = in.nextFloat();

        System.out.printf("Digite a nota opcional, caso não possua, insira um valor negativo qualquer\n");
        avaliacao3 = in.nextFloat();

        baixa = (avaliacao1 < avaliacao2) ? avaliacao1 : avaliacao2;
        alta = (avaliacao1 > avaliacao2) ? avaliacao1 : avaliacao2;

        baixa = (avaliacao3 > 0 && avaliacao3 > baixa) ? avaliacao3 : baixa;

        System.out.printf("A media é : %f", (alta + baixa)/2);
    }
}
