public class exercicio4 {

    public static void main(String[] bernardo) {

        System.out.println("As saídas dos programas A e o C são equivalentes");

    }
    
}
