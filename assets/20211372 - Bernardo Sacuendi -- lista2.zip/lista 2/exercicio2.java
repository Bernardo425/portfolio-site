public class exercicio2 {

    public static void main(String[] bernardo) {
        
        int i = 5;
        int v = 6;
        boolean item = (i> 10 || v<= 50);
        System.out.println(item);
        
        
    }
    
}
