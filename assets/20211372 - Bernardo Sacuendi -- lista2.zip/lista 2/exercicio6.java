import java.util.Scanner;

public class exercicio6 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        double salario; 
        double novo; 
        String classificacao;

        //pedindo o salario
        System.out.printf("Insira o salario: ");
        salario = in.nextFloat();

        in.nextLine();
        //pedindo a calassificacao
        System.out.printf("Insira a classificacao: Excelente - Bom - Mau\n");
        classificacao = in.nextLine();


        switch(classificacao){
            case "Excelente": 
                novo = (salario * 0.6);
                break;
            case "Bom": 
                novo = (salario * 0.4);
                break;
            case "Mau": 
                novo = (salario * 0.15);
                break;
            default: 
                novo = salario;
        }

        System.out.printf("O novo salario é: %f com aumento de %f", novo, novo - salario);
    }
}
