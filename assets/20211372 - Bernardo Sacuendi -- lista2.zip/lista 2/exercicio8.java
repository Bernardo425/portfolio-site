import java.util.Scanner;

public class exercicio8 {
    public static void main(String[] bernrado) {
        
        Scanner in = new Scanner(System.in);
        System.out.println("Shows");
        System.out.println("Tao Tui\nMini Band e os Amigos\nKalê\nRaio de Luz");
        System.out.println("Escolha o show e a quantidade de bilhetes");
        String show = in.next();
        in.nextLine();
        int quntdd = in.nextInt();
       
        if(show.equalsIgnoreCase("Tao Tui")){
            System.out.println("Vai para o show "+(show)+" as 21:00 de 03/042023/ o preço "+(quntdd*15000)+" bilhetes");
        }else if(show.equalsIgnoreCase("Mini Band e os Amigos")){
            System.out.println("Vai para o show "+(show)+" as 21:00 de 03/042023/ possui "+(quntdd*3500)+" bilhetes");
        }else if(show.equalsIgnoreCase("Kalê")){
            System.out.println("Vai para o show "+(show)+" as 21:00 de 03/042023/ possui "+(quntdd*5000)+" bilhetes");
        }else if(show.equalsIgnoreCase("Raio de Luz")){
            System.out.println("Vai para o show "+(show)+" as 21:00 de 03/042023/ possui "+(quntdd*12000)+" bilhetes");
        }else
            System.out.println("Opção inválida");
    }
    
}
