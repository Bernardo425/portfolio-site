import java.util.Scanner;

public class exercicio3 {
    public static void main(String[] bernardo){
        Scanner in = new Scanner(System.in);
        int voto, c1, c2, c3, nulo, branco;
        c1 = c2 = c3 = branco = nulo = 0;
        System.out.printf("Insira o Voto. (Insira 0 apar terminar a leitura): ");
        voto = in.nextInt();
        while(voto != 0){
            switch(voto){
                case 1: c1++; break;
                case 2: c1++; break;
                case 3: c1++; break;
                case 4: nulo++; break;
                case 5: branco++; break;
                case 0: System.out.printf("Saindo ..."); break;
                default:  System.out.printf("Valor de entrada inválido, tente novamente");
            }
            System.out.printf("Insira o Voto. (Insira 0 apar terminar a leitura): ");
            voto = in.nextInt();
        }

        System.out.printf("Número de votos para o candidato 1: %d\n", c1);
        System.out.printf("Número de votos para o candidato 2: %d\n", c2);
        System.out.printf("Número de votos para o candidato 3: %d\n", c3);

        System.out.printf("Número de votos nulos: %d\n", nulo);
        System.out.printf("Número de votos brancos: %d\n", branco);

        

    }
}
