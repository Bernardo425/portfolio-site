import java.util.Scanner;

public class exercicio6 {


    public static void main(String[] bernardo) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Insira o N");
        
        int controlador = 0;
        int aux  = 1;
        int N = in.nextInt();
        for (int i = 1; i <= N; i++) {
            
            if(controlador == 0){
                System.out.print(aux);
                controlador = 3;
            }else if(controlador == 3){
                System.out.print(aux+3);
                controlador = 4;
            }else if(controlador == 4){
                System.out.print(aux+3);
                controlador = 0;
                aux++;
                
            }
            
        }
        
        
    
    
    }
    
}
