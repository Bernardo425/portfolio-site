public class exercicio8 {
    public static void main(String[] bernardo) {
         long aux = 1L;
        for (int i = 0; i != 8; i++) {
            for (int j = 0; j != 8; j++) {
                
                if(aux == 1){
                    System.out.print("1 - ");
                    
                }else{
                    System.out.print(aux+"- ");
                }
                aux = aux * 2;
            }
            System.out.println("");
        }
        
        
        
        
    }
    
}
