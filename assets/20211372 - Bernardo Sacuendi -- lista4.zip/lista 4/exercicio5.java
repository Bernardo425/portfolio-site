import java.util.Scanner;

public class exercicio5 {
    public static void main(String[] bernardo) {
        
        float avaliacaoOpcional = 0;
        Scanner in = new Scanner(System.in);
        System.out.printf("Insira as duas notas das avaliações");
        float nota1 = in.nextFloat();
        float nota2 = in.nextFloat();
        
        System.out.printf("Existe nota de uma avaliação opcional?");
        String resposta= in.next();
        if(resposta.equalsIgnoreCase("sim"))
            avaliacaoOpcional = in.nextFloat();
        else
            avaliacaoOpcional = -1;
        
       float resultado;
       
       resultado = (0 > avaliacaoOpcional)? (nota1 + nota2): 0;
     
       if (resultado == 0 && nota1 > nota2 && nota2 < avaliacaoOpcional )
           resultado=nota1+avaliacaoOpcional;
       else if(resultado == 0 && nota1 < nota2 && nota1 < avaliacaoOpcional)
           resultado=nota2+avaliacaoOpcional;
       else
            System.out.println("O resultado é : ");
           
        System.out.print((resultado/2));

    }
    
}
