import java.util.Scanner;

public class exercicio2 {
    public static void main(String[] bernardo){
        Scanner in = new Scanner(System.in);
        int i = 1;
        int idade, quantidade;
        float peso, media;
        media = quantidade = 0;
        
        for(; i<= 22; i++){
            System.out.printf("======Dados do Atleta %d======\n", i);
            System.out.printf("Insira a idade: ");
            idade = in.nextInt();
            System.out.printf("Insira o peso: ");
            peso = in.nextInt();
            if(peso > 80) quantidade++;
            media += idade;
        }

        System.out.printf("Quantidade de atletas com mais de 8kg: %d\n", quantidade);
        System.out.printf("A média das idades é: %.2f", media/(i-1));
    }
}
