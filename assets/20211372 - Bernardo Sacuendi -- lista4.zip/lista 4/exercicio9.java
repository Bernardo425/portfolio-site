import java.util.Scanner;

public class exercicio9 {

    public static void main(String[] bernardo) {
        Scanner in = new Scanner(System.in);
        
        System.out.println("Insira o número");
        
        int numero = in.nextInt();
        int resultado = 0, aux = numero;
        while(aux > 0){
            int fact = 1;
            for (int i = (aux % 10); i != 0; i--)
                fact*=i; 
            resultado+=fact;
            aux/=10;
        }
        if(resultado == numero )
            System.out.println("Forte");
        else
            System.out.println("Não é forte");
        
    }
    
}
