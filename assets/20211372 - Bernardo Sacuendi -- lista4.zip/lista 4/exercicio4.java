public class exercicio4 {
    public static void main(String[] bernardo){
        int i = 1, y = 1001;
        for(; i <= 5;y++) if((y % 11) == 5) i++;
        System.out.printf("O Quinto número maior que 1000 é %d", --y);

    }
}
