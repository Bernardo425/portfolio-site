import java.util.Scanner;

public class exercicio1 {
    public static void main(String[] bernardo){
        Scanner in = new Scanner(System.in);
        int i, j, num, count;
        i = j = count = 1;

        for(; i <= 10; i++){
            System.out.printf("Digite um número: ");
            num = in.nextInt();
            while(j <= (num / 2)){
                if((num % j) == 0) count++;
                j++;
            }
            if(count > 2) System.out.printf("O número %d não é primo\n", num);
            else System.out.printf("O número %d é primo\n", num);
            count = j = 1;
        }

    }
}
