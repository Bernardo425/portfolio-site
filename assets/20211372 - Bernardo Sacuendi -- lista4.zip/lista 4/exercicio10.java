import java.util.Scanner;

public class exercicio10 {

    public static void main(String[] bernardo) {
        
        Scanner in = new Scanner(System.in);
        System.out.println("Quantos motoristas deseja inserir no sistema ?");
        int numeroDeMotoristas = in.nextInt();
        int maiorDivida = 0,numeroMotorista = 0,totalDivida = 0;
        
        for (int i = 0; i < 10; i++) {
            
            System.out.println("Insira o numero da carta e o numero de multas ");
            int numeroDaCarta = in.nextInt();
            int numeroDeMultas = in.nextInt();
            int totalDividaMotorita = 0;
            
            for (int j = 0; j < numeroDeMultas; j++) {
            
                System.out.println("Insira o valor da "+(j+1)+"ª multa");
                int valor = in.nextInt();
                totalDividaMotorita+=valor;
            }
            System.out.println("Total da divida do motorista de carta numero "+numeroDaCarta+" "+totalDividaMotorita);
            if(totalDividaMotorita > maiorDivida){
                maiorDivida = totalDividaMotorita;
                numeroMotorista = numeroDaCarta;
            }
            totalDivida+=totalDividaMotorita;    
            
        }
        
        System.out.println("O total de fundos arrecadados "+totalDivida);
        System.out.println("O motorista com maior divida possui a carta numero "+numeroMotorista);
        
        
        
    }
    
}
