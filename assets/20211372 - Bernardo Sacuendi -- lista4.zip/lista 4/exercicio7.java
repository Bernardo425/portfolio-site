import java.util.Scanner;

public class exercicio7 {

    public static void main(String[] bernardo) {
        Scanner in = new Scanner(System.in);
        System.out.println("Insira um número");
        int numero = in.nextInt();
        
        while((numero % 10) != 0){
            System.out.print(numero%10);
            numero/=10;
            
        }
    }
}
