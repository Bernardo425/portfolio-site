/*
 * Feito por CTO 
 */

 import java.util.Scanner;

public class exercicio1 {
    public static void main(String bernardo[]){
    Scanner in = new Scanner(System.in);
    int numero;
    double media = 0;
    int i;

    System.out.printf("Digite um numero");
    numero = in.nextInt();

    for(i = 1; numero != 99; i++){
        media += numero;
        numero = in.nextInt();
    }  
        
    media /= i;
    
    System.out.printf("A média é: %f", media);
    
    }
}
