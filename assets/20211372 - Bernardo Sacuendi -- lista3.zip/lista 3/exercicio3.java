/*
 * Feito por CTO 
 */

 import java.util.Scanner;

public class exercicio3 {
    public static void main(String bernardo[]){
        Scanner in = new Scanner(System.in);
        int numero, i, fatorial = 1;
    
        System.out.printf("Digite um numero \n");
        numero = in.nextInt();
    
        for(i = numero; i > 0; i--) fatorial *= i;

        System.out.printf("o fatorial é: %d", fatorial);
    }
}
