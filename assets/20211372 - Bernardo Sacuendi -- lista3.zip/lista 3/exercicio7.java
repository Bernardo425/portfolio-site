
import java.util.Scanner;

public class exercicio7 {

    public static void main(String[] bernardo) {
        
        Scanner in = new Scanner(System.in);
        System.out.printf("Insira 2 números");
        int numero1 = in.nextInt();
        int numero2 = in.nextInt();
        
        
        int resto1= 0, resto2 = 0;
        int maior = (numero1 > numero2)? numero1 : numero2;
        for(int i = 1;i != maior; i++ ){
            if(numero1 % i == 0)
                resto1+=i;
            if(numero2 % i == 0)
                resto2+=i;
        }
        
        if(resto1 == numero2 && resto2 == numero1) System.out.printf("Os números são amigos");
        else System.out.printf("Não são amigos");

    }
    
}
