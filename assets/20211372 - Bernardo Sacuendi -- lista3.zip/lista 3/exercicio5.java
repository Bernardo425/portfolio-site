import java.util.Scanner;

public class exercicio5 {

    public static void main(String[] bernardo) {
        Scanner leitura = new Scanner (System.in);
        System.out.println("Insira o N");
        int enesimo = leitura.nextInt(); 
        System.out.println("S = 1");
        for(int cont = 1 ; cont != enesimo ; cont++ ) System.out.print(" + "+(cont)+" / "+(2*cont)+1);
            
    }
    
}
