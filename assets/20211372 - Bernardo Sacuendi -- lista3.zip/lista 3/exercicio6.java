/*
 * Feito por CTO 
 */

import java.util.Scanner;
import java.lang.Math;

public class exercicio6 {   

    public static void main(String bernardo[]){

        Scanner in = new Scanner(System.in);
        int numero, i, x, y, aux;
        x = 0; 
        y = 1;
    
        System.out.printf("Insira um valor: ");
        numero = in.nextInt();
        
        System.out.printf(" %d  %d ", x, y);

        for(i = 1;i <= 10; i++){
            aux = x + y;
            System.out.printf(" %d ", aux);
            x = y;
            y = aux;
        }
    }


}
