import java.util.Scanner;
public class exercicio2 {
    public static void main(String[] bernardo) {
        Scanner in = new Scanner (System.in);
        int numero, maior = 0;
        for(int cont = 10; cont != 0; cont--){
            System.out.println("Insira um número");
            numero = in.nextInt();
            if(numero > maior) maior = numero;
        }
        System.out.println("O maior número "+maior);
    }
    
}
