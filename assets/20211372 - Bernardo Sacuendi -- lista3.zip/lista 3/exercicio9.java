import java.util.Scanner;


public class exercicio9 {
    public static void main(String[] bernardo) {
        
        Scanner in  = new Scanner(System.in);
        System.out.println("Insira X e N");
        int x = in.nextInt();
        int n = in.nextInt();

        int cont = 1;
        
        String resultado = "cos = 1";
        
        for (int i = 2; i <= n; i+=2) {
            
            int baixo = i;
            int cima =(int) Math.pow(x, i);
            
            for (int j = baixo-1; j > 0; j--)
                baixo*=j;

            if( cont % 2 == 0){
                resultado += " + ";
                resultado+=(cima);
                resultado+="/";
                resultado+=(baixo);
            }
            else{
                resultado += " - ";
                resultado+=(cima);
                resultado+="/";
                resultado+=(baixo);
            }
            cont++;
        }
        
        System.out.println(resultado);
        
        
    }
    
}
