import java.util.Scanner;

public class exercicio4 {

    public static void main(String[] bernardo) {
        Scanner in = new Scanner (System.in);
        int tempototal;
        System.out.println("Insira a massa inicial");
        float massa = in.nextFloat();
        for(tempototal = 110; massa > 0.8; tempototal+=110) massa/=2;
        System.out.println("Foram necessários "+tempototal+(" segundos para que a massa incicial fosse igual ou inferior a 0.8"));

    }
    
}
