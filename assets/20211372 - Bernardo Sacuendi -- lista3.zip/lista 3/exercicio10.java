import java.util.Scanner;

public class exercicio10 {

    public static void main(String[] bernardo) {
        
        Scanner in = new Scanner(System.in);
        System.out.println("Insira o N");
        int n = in.nextInt();
        
        for (int i = 0; i != n; i++) {
            
            for (int j = 0; j != n; j++) {
            
                if(i > j)
                    System.out.print(".");
                else
                    System.out.print("*");
                
            }
            System.out.println("");
            
        }

    }
    
}
