import java.util.Scanner;

public class exercicio8 {
    public static void main(String[] bernardo) {
        Scanner in = new Scanner(System.in);
        System.out.printf("Inisra um número");
        int numero = in.nextInt();
        
        int resultado;
        resultado = 0;
        
        for(int i = 1; i < numero && resultado != numero;i+=2){    
           
            for (int j = i; resultado < numero;  j+=2) resultado+=j;
            
            
            if(resultado != numero) resultado = 0;
        
        }
        
        if(resultado == numero)
            System.out.printf("É um número quadrado");
        else
            System.out.printf("Não é um número quadrado");
        
        
    }
    
}
