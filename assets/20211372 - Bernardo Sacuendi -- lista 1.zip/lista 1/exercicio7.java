import java.util.Scanner;

public class exercicio7 {
    public static void main(String bernardo[]){
        Scanner in = new Scanner(System.in);
        int x1, x2, x3, x4;
        int mais_velho, mais_velha;
        int mais_novo, mais_nova;

        //Lendo as idades dos homens
        System.out.printf("Insira a idade do primeiro homem\n");
        x1 = in.nextInt();

        System.out.printf("Insira do segundo homem\n");
        x2 = in.nextInt();

        //Lendo as idades das mulheres
        System.out.printf("Insira a idade da primeira mulher\n");
        x3 = in.nextInt();

        System.out.printf("Insira a idade da segunda mulher\n");
        x4 = in.nextInt();

        //achando o mais velho e mais a mais velha
        mais_velho = (x1 > x2) ? x1 : x2;
        mais_novo = (x1 < x2) ? x1 : x2;
        mais_velha = (x3 > x4) ? x3 : x4;
        mais_nova = (x3 < x4) ? x3 : x4;

        System.out.printf("a soma das idades do homem mais velho com a mulher mais nova é: %d", (mais_velho + mais_nova));
        System.out.printf("o produto das idades do homem novo com a mulher mais velha é: %d", (mais_novo * mais_velha));
    }

}
