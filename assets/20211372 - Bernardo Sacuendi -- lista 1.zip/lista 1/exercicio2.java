/*
 * Feito por CTO 
 */

import java.util.Scanner;

public class exercicio2 {
    public static void main(String bernardo[]){
        Scanner in = new Scanner(System.in);
        float raio;
        double area, comprimento;

        //Lendo o valor do raio
        System.out.printf("Insira o raio da circunferência\n");
        raio = in.nextFloat();

        //Calculando o valor da area
        area = Math.PI * Math.pow(raio, 2);

        //calculando valor do comprimento
        comprimento = 2 * Math.PI * raio;

        //Apresentando os resultados finais
        System.out.printf("O valor do comprimento é: %f\n", comprimento) ;
        System.out.printf("O valor da area é: %f", area) ;
    }
}
