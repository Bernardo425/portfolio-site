/*
 * Feito por CTO 
 */

 import java.util.Scanner;

class Exercicio1{
    public static void main(String bernardo[]){

        Scanner in = new Scanner(System.in);
        float x1, x2;
        float y1, y2;
        double distancia;

        //Lendo os valores de x
        System.out.println("Digite o valor de x1");
        x1 = in.nextInt();
        System.out.println("Digite os valor de x2");
        x2 = in.nextInt();

        //Lendo os valores de y
        System.out.println("Digite o valor de y1");
        y1 = in.nextInt();
        System.out.println("Digite os valor de y2");
        y2 = in.nextInt();

        //Calculando a distância
        distancia = Math.sqrt(Math.pow( x1-x2 , 2) + Math.pow( y1-y2 , 2) );

        //Apresnentando os valores
        System.out.printf("A disntância entre (%.1f|%.1f) e (%.1f|%.1f) é: %f", x1, y1, x2, y2, distancia);

    }
}