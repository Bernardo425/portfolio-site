import java.util.Scanner;

public class exercicio5 {
    public static void main(String bernardo[]){
        Scanner in = new Scanner(System.in);
        int numero;

        //Lendo o numero
        System.out.printf("Insira um numero inteiro\n");
        numero = in.nextInt();

        if(((numero % 5) == 0) && ((numero % 7) == 0)) System.out.printf("é multiplo de 5 e 7\n");
        else System.out.printf("não é multiplo de 5 e 7\n");
    }
}
