import java.util.Scanner;

import javax.print.event.PrintEvent;
public class exercicio8 {
    public static void main(String bernardo[]){
        Scanner in = new Scanner(System.in);
        char letra;

        System.out.printf("Digite a letra\n");
        letra = in.next().charAt(0);

        switch(letra){
            case 'a':
            case 'A':
            case 'e':
            case 'E':
            case 'i':
            case 'I':
            case 'o':
            case 'O':
            case 'u':
            case 'U':
                System.out.printf("é uma vogal\n");  
                break;
            default:
                System.out.printf("é uma consoante\n"); 

        }
    
    }
}
