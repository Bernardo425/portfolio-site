import java.util.Scanner;

public class exercicio9 {
    public static void main(String[] bernardo){
        Scanner in = new Scanner(System.in);
        int n1, n2, n3, escolha;
        int maior, medio, menor;
        
        System.out.printf("Digite o primeiro número: ");
        n1 = in.nextInt();

        System.out.printf("Digite o sugundo número: ");
        n2 = in.nextInt();

        System.out.printf("Digite o terceiro número: ");
        n3 = in.nextInt();

        System.out.printf("Escolha uma das opções: \n1 - Maior Número \n2- Menor Número \n3- soma dos quadrados dos números \n4- Multiplicação dos dois maiores \n5-Ordem decrescente \n: ");
        escolha = in.nextInt();

        maior = (n1 > n2)? n1 : n2;
        maior = (maior > n3)? maior : n3;

        menor = (n1 < n2)? n1 : n2;
        menor = (menor < n3)? menor : n3;

        medio = ((maior != n3) && (menor != n3))? n3 : ((maior != n2) && (menor != n2))? n2 : n1;


        switch (escolha) {
            case 1:
                System.out.printf("O Maior número é: %d", maior);
                break;
            case 2:
                System.out.printf("O Menor número é: %d", menor);
                break;
            case 3: 
                System.out.printf("a soma dos quadrados dos números é: %.0f", Math.pow(n1, 2) + Math.pow(n2, 2) + Math.pow(n3, 2));
                break;
            case 4:
                System.out.printf("A Multiplicação dos dois maiores é: %d", medio * maior);
                break;
            case 5:
                System.out.printf("Ordem decrescente: %d | %d | %d", maior,  medio,  menor);
                break;
            default:
                System.out.printf("Entrada Inválida\n");
                break;
        }

        System.out.printf("\n");

    }
}
