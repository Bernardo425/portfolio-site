import java.util.Scanner;

public class exercicio6 {
    public static void main(String bernardo[]){
        Scanner in = new Scanner(System.in);
        int x1, x2, x3;

        //Lendo os numeros
        System.out.printf("Insira o primeiro numero\n");
        x1 = in.nextInt();

        System.out.printf("Insira o segundo numero\n");
        x2 = in.nextInt();

        System.out.printf("Insira o terceiro numero\n");
        x3 = in.nextInt();

        if((x1 == x2) && (x1 == x3) && (x3 == x2) ) System.out.printf(" são iguais \n");
        else System.out.printf("não são iguais\n");
    }
}
