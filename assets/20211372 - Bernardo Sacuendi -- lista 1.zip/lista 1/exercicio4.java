import java.util.Scanner;

public class exercicio4 {
    public static void main(String bernardo[]){
        Scanner in = new Scanner(System.in);
        int numero;

        //Lendo o numero
        System.out.printf("Insira o numero\n");
        numero = in.nextInt();

        if((numero % 5) == 0 ) System.out.printf("é multiplo de 5\n");
        else System.out.printf("não é multiplo de 5\n");
    }
}
