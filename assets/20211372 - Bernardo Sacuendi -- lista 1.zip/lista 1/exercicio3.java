/*
 * Feito por CTO 
 */

 import java.util.Scanner;

public class exercicio3 {
    public static void main(String bernardo[]){
    Scanner in = new Scanner(System.in);

        float hp, lp;
        float la, ha;

        float ap, aa;

        int numero_de_azulejos;
        //Inserindo os dados da parede
        System.out.printf("Digite a altura da parede\n");
        hp = in.nextFloat();

        System.out.printf("Digite a largura da parede\n");
        lp = in.nextFloat();

        //Inserindo os dados do azulejo
        System.out.printf("Digite a altura do azulejo\n");
        ha = in.nextFloat();

        System.out.printf("Digite a largura do azulejo\n");
        la = in.nextFloat();

        //calculando a area da parede
        ap = hp * lp;
        //calculando a area do azulejo
        aa = ha * la;

        //calculando quantos azulejos são necessários
        numero_de_azulejos = (int) Math.ceil(ap / aa);

        System.out.printf("São necessários %d azulejos para cobrir toda parede\n", numero_de_azulejos);
    }
}
