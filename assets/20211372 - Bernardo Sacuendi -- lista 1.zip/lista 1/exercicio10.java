


import java.util.Scanner;

public class exercicio10 {
    public static void main(String[] bernardo) {
        Scanner in = new Scanner(System.in);
        
        System.out.printf("Isnira o preço");
        float preco = in.nextFloat();

        System.out.printf("Código de pagamento");
        int escolha = in.nextInt();
        
        switch (escolha) {
            case 1:
                preco =(float) ((preco)+(preco*0.1));
                break;
            case 2:
                preco =(float) ((preco)-(preco*0.05));
                break;
            case 3:
                preco =(float) 2*(preco);
                break;
            case 4:
                preco =(float) (3*((preco)+(preco*0.1)));
                break;
            default:
                System.out.printf("Inválido");
        }

        System.out.printf("O Resultado é: %.2f", preco);

        
    }
    
}
